/*
* Useful Functions
*/
#include "FreeRTOS.h"

portTickType Seconds2Ticks(const float);
