#ifndef TIMER_H
#define TIMER_H


void initTimer0(void);

void startTimer0Int(void);

void stopTimer0Int(void);

void timerTX(void);

void timerRX(void);

#endif